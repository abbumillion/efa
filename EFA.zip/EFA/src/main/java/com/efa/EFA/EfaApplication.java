package com.efa.EFA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EfaApplication {

	public static void main(String[] args) {
		SpringApplication.run(EfaApplication.class, args);
	}

}
