package com.efa.EFA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EfaApplicationTests {

	@Test
	void contextLoads() {
	}

}
